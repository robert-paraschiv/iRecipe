package com.rokudoz.irecipe.Models;

public final class PossibleIngredients {
    public static String[] getIngredientsNames(){
        return new String[] {"potatoes", "cheese", "apples", "salt", "gorgonzola"};
    }

}
